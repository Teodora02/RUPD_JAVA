public class Constants {
    public static int PORT = 4445;                  // communication port
    public static String SERVER_NAME = "localhost"; // server address
}
